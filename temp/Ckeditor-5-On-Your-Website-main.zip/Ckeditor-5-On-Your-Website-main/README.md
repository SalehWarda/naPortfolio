# How to configure ckeditor 5 on your site
Learn how to install, integrate and configure CKEditor 5 Builds on your website. 

In the tutorial i show you how to use the **ClassicEditor** ,**InlineEditor** and **BalloonEditor** build.

Tutorial:: [tutorial](https://youtu.be/Mz8HJjA5lZA)

Read more on the official Ckeditor [Documentation](https://ckeditor.com/docs/ckeditor5/latest/builds/guides/overview.html) page.