---
name: "⭐ Feature request"
about: Propose something new.
title: ''
labels: type:feature
assignees: ''

---

## 📝 Provide a description of the new feature

_What is the expected behavior of the proposed feature?_

---

If you'd like to see this feature implemented, add a 👍 reaction to this post.
