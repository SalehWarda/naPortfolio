---
category: examples-builds
order: 20
classes: main__content--no-toc
---

# Inline editor

{@link installation/advanced/predefined-builds#inline-editor Inline editor} lets you create your content directly in its target location with the help of a floating toolbar that apprears when the editable text is focused.

In this example the {@link features/images-styles image styles} configuration was changed to enable left- and right-aligned images.

{@snippet examples/inline-editor}
