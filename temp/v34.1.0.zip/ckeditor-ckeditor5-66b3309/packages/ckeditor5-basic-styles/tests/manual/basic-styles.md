## Basic styles

1. The data should be loaded with:
  * italic _"This"_,
  * bold **"editor"**,
  * underline "instance",
  * strikethrough ~~"is"~~,
  * code `"an"`,
  * subscript X<sub>1</sub>,
  * superscript X<sup>2</sup>.
2. The second sentence should bold the following words: `bold`, `600`, `700`, `800`, `900`.
3. Test the bold, italic, strikethrough, underline, code, subscript and superscript features live.
