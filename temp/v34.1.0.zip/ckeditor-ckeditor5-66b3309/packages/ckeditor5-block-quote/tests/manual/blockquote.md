## Block quote feature

Check block quote related behaviors:

* applying quotes to multiple blocks,
* removing quotes,
* <kbd>Enter</kbd> (should leave quote when pressed in an empty block),
* <kbd>Backspace</kbd>,
* undo/redo,
* applying headings and lists,
* stability when used with nested lists,
* stability when used with nested block quotes.
